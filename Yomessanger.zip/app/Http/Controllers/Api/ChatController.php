<?php

namespace App\Http\Controllers\Api;

use App\Chat;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $user = auth()->user();
        $chats = $user->chats()->with('');
    }

}
